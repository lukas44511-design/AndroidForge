# FoxLab Injector — Android source

This is a fresh Android Studio project for the workflow discussed in chat.

## Current scope
- Select an already-decompiled APK folder using Android's Storage Access Framework.
- Select a native `.so` file.
- Copy it to `lib/arm64-v8a/`.
- Locate `UnityPlayerActivity.smali` recursively.
- Add a `System.loadLibrary("Name")` call to `onCreate`.
- Export the modified decompiled project as a ZIP.

## Important status / limitations
This source is a starter implementation, not a verified release. It does **not** yet decompile an APK or rebuild a complete APK. The requested next feature is APK decompilation and unsigned APK rebuilding (for example through a properly integrated, Android-compatible Apktool runtime). Do not treat the exported ZIP as an APK.

The Smali patcher currently handles `.locals` methods and deliberately stops on `.registers` methods rather than risk corrupting parameter registers. A production version should use a Smali parser or carefully calculate register/parameter shifts, and should validate the resulting Smali before export. Test only on APKs you own or are authorized to modify.

## Build
Open this folder in Android Studio with JDK 17. Let Gradle sync, then choose Build > Build Bundle(s) / APK(s) > Build APK(s).

The build has not been run or tested in this environment.
