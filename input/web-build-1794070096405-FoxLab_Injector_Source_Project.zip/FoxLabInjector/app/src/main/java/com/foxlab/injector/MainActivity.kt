package com.foxlab.injector

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.widget.*
import androidx.documentfile.provider.DocumentFile
import java.io.*
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class MainActivity : Activity() {
    private val pickTree = 10
    private val pickSo = 11
    private var projectTree: Uri? = null
    private var soUri: Uri? = null
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 32, 28, 24)
        }
        layout.addView(TextView(this).apply {
            text = "🦊 FoxLab Injector"
            textSize = 25f
        })
        layout.addView(TextView(this).apply {
            text = "Choose an APK decompile folder, then a native .so library. Inject patches UnityPlayerActivity and exports the modified project as a ZIP."
            textSize = 15f
        })
        fun button(label: String, action: () -> Unit) {
            layout.addView(Button(this).apply { text = label; setOnClickListener { action() } })
        }
        button("1. Select decompiled APK folder") {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), pickTree)
        }
        button("2. Select .so library") {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE)
            }
            startActivityForResult(i, pickSo)
        }
        button("3. Inject and export project ZIP") { runInjection() }
        status = TextView(this).apply { text = "Ready."; textSize = 14f }
        layout.addView(status)
        setContentView(ScrollView(this).apply { addView(layout) })
    }

    @Deprecated("Activity result API kept minimal for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        when (requestCode) {
            pickTree -> {
                projectTree = data.data
                contentResolver.takePersistableUriPermission(data.data!!,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                status.text = "Project folder selected."
            }
            pickSo -> { soUri = data.data; status.text = "Native library selected." }
        }
    }

    private fun runInjection() {
        val treeUri = projectTree
        val libraryUri = soUri
        if (treeUri == null || libraryUri == null) {
            status.text = "Select both the decompiled project folder and a .so file."
            return
        }
        Thread {
            try {
                val root = DocumentFile.fromTreeUri(this, treeUri)
                    ?: error("Cannot open project folder")
                val soName = queryName(libraryUri)
                require(soName.endsWith(".so", true)) { "Selected file must end in .so" }
                val loadName = soName.removePrefix("lib").removeSuffix(".so")
                val bytes = contentResolver.openInputStream(libraryUri)?.use { it.readBytes() }
                    ?: error("Cannot read .so file")
                val libDir = ensureDir(root, "lib") .let { ensureDir(it, "arm64-v8a") }
                val existing = libDir.findFile(soName)
                existing?.delete()
                libDir.createFile("application/octet-stream", soName)?.let {
                    contentResolver.openOutputStream(it.uri, "w")!!.use { out -> out.write(bytes) }
                } ?: error("Could not copy native library")

                val smali = findNamed(root, "UnityPlayerActivity.smali")
                    ?: error("UnityPlayerActivity.smali not found. Make sure the APK is decompiled.")
                val original = contentResolver.openInputStream(smali.uri)!!.bufferedReader().use { it.readText() }
                val patched = patchOnCreate(original, loadName)
                contentResolver.openOutputStream(smali.uri, "wt")!!.bufferedWriter().use { it.write(patched) }

                val out = File(cacheDir, "FoxLab_Injected_Project.zip")
                ZipOutputStream(BufferedOutputStream(FileOutputStream(out))).use { zip ->
                    zipTree(root, "", zip)
                }
                runOnUiThread { status.text = "Injected $soName and patched UnityPlayerActivity. Export: ${out.absolutePath}" }
                // Share/save the generated ZIP through Android's document picker.
                runOnUiThread {
                    val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "application/zip"
                        putExtra(Intent.EXTRA_TITLE, "FoxLab_Injected_Project.zip")
                    }
                    pendingZip = out
                    startActivityForResult(intent, 12)
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Error: ${e.message}" }
            }
        }.start()
    }

    private var pendingZip: File? = null

    private fun patchOnCreate(src: String, name: String): String {
        val call = "    const-string v0, \\"$name\\"\\n    invoke-static {v0}, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V"
        if (src.contains("Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V") &&
            src.contains("\\"$name\\"")) return src
        val methodStart = src.indexOf(".method")
        val onCreate = Regex("(?m)^\\.method[^\\n]*onCreate\\(Landroid/os/Bundle;\\)V[^\\n]*$")
            .find(src) ?: error("onCreate(Bundle) method not found")
        val bodyStart = onCreate.range.last + 1
        val end = src.indexOf(".end method", bodyStart)
        if (end < 0) error("Could not locate end of onCreate")
        val body = src.substring(bodyStart, end)
        val regs = Regex("(?m)^\\s*\\.locals\\s+(\\d+)").find(body)
        val registers = Regex("(?m)^\\s*\\.registers\\s+(\\d+)").find(body)
        val patchedBody = when {
            regs != null -> {
                val n = regs.groupValues[1].toInt()
                body.replaceFirst(regs.value, regs.value.replace(n.toString(), (n + 1).toString())) +
                    "" // instruction inserted below
            }
            registers != null -> error("onCreate uses .registers; safe parameter-register adjustment needs manual review")
            else -> error("No .locals or .registers directive found in onCreate")
        }
        val insertAt = bodyStart + Regex("(?m)^\\s*\\.locals\\s+\\d+\\s*$").find(body)!!.range.last + 1
        return src.substring(0, insertAt) + "\\n" + call + "\\n" + src.substring(insertAt)
    }

    private fun queryName(uri: Uri): String {
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) return it.getString(0)
        }
        return uri.lastPathSegment ?: "library.so"
    }
    private fun ensureDir(parent: DocumentFile, name: String): DocumentFile =
        parent.findFile(name)?.takeIf { it.isDirectory } ?: parent.createDirectory(name)
        ?: error("Cannot create $name")
    private fun findNamed(dir: DocumentFile, name: String): DocumentFile? {
        dir.listFiles().forEach { f ->
            if (f.isFile && f.name == name) return f
            if (f.isDirectory) findNamed(f, name)?.let { return it }
        }
        return null
    }
    private fun zipTree(dir: DocumentFile, prefix: String, zip: ZipOutputStream) {
        for (f in dir.listFiles()) {
            val name = if (prefix.isEmpty()) f.name ?: continue else "$prefix/${f.name ?: continue}"
            if (f.isDirectory) zipTree(f, name, zip)
            else {
                zip.putNextEntry(ZipEntry(name))
                contentResolver.openInputStream(f.uri)?.use { it.copyTo(zip) }
                zip.closeEntry()
            }
        }
    }
}
